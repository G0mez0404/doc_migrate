from tkinter import *
import pymysql
from tkinter import messagebox

def insertar_datos():
    bd = pymysql.connect(
        host="localhost",
        user="root",
        password="",
        db="base_datos",
        port="3306",
    )
    
    mcursor = bd.cursor()
    
    sql = "INSERT INTO appprojem_mUsuarios (login, contraseña) VALUES('{0}, {1}')".format(texto_usuario.get(), texto_contraseña.get())
    
    try:
        mcursor.execute(sql)
        bd.commit()
        messagebox.showinfo(message="registro valido", title="AVISO")
        
    except:
        bd.rolback()
        messagebox.showinfo(message="registro no valido", title="AVISO")
        
    bd.close()


root = Tk()
root.title("login")
root.geometry("1100x600+100+50")
root.resizable(FALSE,FALSE)
    
frame_registro = Frame(root, bg="white")
frame_registro.place(x=150, y=150, height=340, width=500)
    
titulo = Label(frame_registro, text="Iniciar sesion",font=("Arial", 35, "bold"), fg="#F50743", bg="white").place(x=90, y=30)
sesion = Label(frame_registro, text="Area de Inicio de sesion",font=("Arial", 15, "bold"), fg="#F50743", bg="white").place(x=90, y=100)

usuario = Label(frame_registro, text="Nombre de usuario",font=("Arial", 15, "bold"), bg="white").place(x=90, y=140)
texto_usuario = Entry(frame_registro, font=("times new roman", 15), bg="lightgray")
texto_usuario.place(x=90, y=170, width=350, height=35)

usuario_contraseña = Label(frame_registro, text="Contraseña",font=("Arial", 15, "bold"), bg="white").place(x=90, y=210)
texto_contraseña = Entry(frame_registro,show="*", font=("times new roman", 15), bg="lightgray")
texto_contraseña.place(x=90, y=240, width=350, height=35)

alerta_btn = Button(frame_registro, text="Contraseña olvidada?", bd=0,font=("times new roman", 12,"bold")).place(x=90,y=280)
registrar_btn = Button(root, text="Registrar", background="white",bd=0,font=("times new roman", 20,"bold"),command=insertar_datos).place(x=300,y=470,width=180,height=40)
root.mainloop()
    