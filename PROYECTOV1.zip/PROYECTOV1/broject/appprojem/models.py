from django.db import models
from django.db.models.fields import CharField, DateField, BooleanField
# Create your models here.
class mUsuarios(models.Model):
    id = models.AutoField(primary_key=True)
    CvPerson = models.IntegerField(null=True)
    login = models.CharField(max_length=50)
    Contraseña = models.CharField(max_length=50)
    FecIni = models.DateField(null=True)
    FecFin = models.DateField(null=True)
    EdoCta = models.BooleanField(null=True)
    
