from django.contrib import admin
from .models import mUsuarios
# Register your models here.
admin.site.register(mUsuarios)