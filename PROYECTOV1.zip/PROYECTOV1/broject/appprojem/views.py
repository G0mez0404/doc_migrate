from django.shortcuts import render
from django.views.generic import TemplateView
from django.contrib.auth.views import LoginView, LogoutView
from django.contrib.auth.mixins import LoginRequiredMixin
from django.urls import reverse_lazy
# Create your views here.
#def show_index(request):
 #   return render(request, 'index.html')
#class showIndex(TemplateView):
 #   template_name = 'index.html'
    
class Login(LoginView):
    next_page = reverse_lazy('main')
    temptemplate_name = 'login.html'
    
    
class Logout(LogoutView):
    next_page = reverse_lazy('login')
    